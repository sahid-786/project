from django.contrib import admin
from app1.models import ContactM
from app1.models import Studentt
# Register your models here.
admin.site.register(ContactM)
admin.site.register(Studentt)
