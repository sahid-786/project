from django.shortcuts import render,redirect
from django.http import HttpResponse
from app1.models import ContactM
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from app1.models import Studentt
# Create your views here.
def home(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def services(request):
    return render(request,'services.html')
def contact(request):
    return render(request,'contact.html')
def register(request):
    return render(request,'register.html')

def userquery(request):
    if request.method=="POST":
        name=request.POST.get("name")
        email=request.POST.get("email")
        contact=request.POST.get("contact")
        message=request.POST.get("message")
        r=ContactM(Name=name, email=email, contact=contact,message=message)
        r.save()
        #return HttpResponse("Request is under process")
        return render(request,'contact.html',{'msg':'Request is under process'})


def registeruser(request):
    if request.method=="POST":
        fname=request.POST.get("fname")
        lname=request.POST.get("lname")
        email=request.POST.get("email")
        password=request.POST.get("password")
        #return HttpResponse(fname+lname+email+password)
        try:
            r=User.objects.create_user(first_name=fname, last_name=lname,email=email,username=email, password=password)
            r.save()
            return render(request,'register.html',{'msg':'A/C Created'})
        except:
            return render(request,'register.html',{'msg':'A/C Already Exsist'})

def userhome(request):
    return render(request,'userhome.html')

def loginuser(request):
    if request.method=="POST":
        email=request.POST.get("email")
        password=request.POST.get("password")
        user=authenticate(username=email, password=password)
        if user is not None:
            login(request,user)
            return redirect("/userhome")
        else:
            return render(request,"index.html",{"msg1":"wrong email or password"})
        
def logoutuser(request):
    logout(request)
    return render(request,"index.html")

def addrecord(request):
    return render(request,'addrecord.html')

def newrecord(request):
    if request.method=="POST":
        name=request.POST.get("name")
        email=request.POST.get("email")
        contact=request.POST.get("contact")
        profile=request.POST.get("profile")
        company=request.POST.get("company")
        city=request.POST.get("city")
        #return HttpResponse(name+email+contact+Profile+company+city)
        r=Studentt(name=name,email=email,contact=contact,profile=profile, company=company,city=city)
        r.save()
        return render(request,'addrecord.html',{'msg':'Record has been saved'})

def completerecord(request):
    r=Studentt.objects.all()
    return render(request,"complete.html",{'data':r})

def searchrecord(request):
    return render(request,'searchrecord.html')





def search_record(request):
    if request.method=="POST":
        name=request.POST.get("name")
        try:
            r=Studentt.objects.filter(name=name).get()
            return render(request,"searchresult.html",{'data':r})
        except:
            return render(request,'pageerror.html',{'data':'sorry..not Exist...'})








def deleterecord(request):
    return render(request,'deleterecord.html')

def delete_record(request):
    if request.method=="POST":
        name=request.POST.get("name")
        Studentt.objects.filter(name=name).delete()
        return redirect("/completerecord")

def changepassword(request):
    return render(request,'changepassword.html')

def change_password(request):
    if request.method=="POST":
        uname=request.POST.get("uname")
        npass=request.POST.get("npass")
        r=User.objects.get(username=uname)
        r.save()
        return render(request,'changepassword.html',{'msg':'password changed !'})

